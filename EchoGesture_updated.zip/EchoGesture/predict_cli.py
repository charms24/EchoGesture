#!/usr/bin/env python3
"""Run predict() on one or more clips and print JSON lines (also writes --out)."""
import argparse
import json

from src.main import predict

parser = argparse.ArgumentParser()
parser.add_argument("clips", nargs="+")
parser.add_argument("--out", help="optional predictions.jsonl path")
args = parser.parse_args()
lines = [json.dumps(predict(clip), separators=(",", ":")) for clip in args.clips]
print("\n".join(lines))
if args.out:
    open(args.out, "w", encoding="utf-8").write("\n".join(lines) + "\n")
