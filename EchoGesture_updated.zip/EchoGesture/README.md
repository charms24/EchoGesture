# EchoGesture Track 02

EchoGesture recognizes word-level ASL clips from WLASL keypoints and provides an offline webcam demo.

## Submission layout

The submission bundle should contain these files at these exact paths:

```text
team_name/
├── README.md
├── src/
│   ├── main.py
│   ├── preprocess.py
│   ├── requirements.txt
│   └── README.md
└── results/
    ├── predictions.json
    ├── predictions.jsonl
    └── results.csv
```

Inference loads up to **three** statically INT8-quantized seeds: `artifacts/model_int8.onnx`, `artifacts/model_seed2_int8.onnx` and `artifacts/model_seed3_int8.onnx` (every `*_int8.onnx` that exists is loaded). Their raw logits are averaged before softmax. The three files together are about 1.4 MB.

## Offline inference

Use Python 3.11 and install `src/requirements.txt`. Place the vocabulary at the repository root as `vocab.json`, or at `data/vocab.json` as a fallback. Call `src.main.predict(video_path)` for a JSON-ready object with `clip_id`, uppercase `prediction`, uppercase `top5`, `confidence`, and `latency_ms`.

`src/preprocess.py` extracts a `(64, 162)` raw landmark sequence and transforms it into the model's `(64, 486)` input by concatenating positions, temporal velocity, and parent-relative vectors. The same transform is used by training and evaluation.

## Build the results files

Pipeline: `build_dataset.py` (videos -> `.npy` landmarks) -> `train.py` (per seed, writes `model.onnx`) -> `quantize_and_eval.py` (static INT8 + results).

```bash
python quantize_and_eval.py --calib data/train --val data/test \
    --device "Galaxy S25, Snapdragon 8 Elite" --avg-power-mw <measured> --thermal-minutes 10
```

`--calib` clips calibrate INT8 activations (class-balanced sample of real training clips). Evaluate on `data/test` (held-out; never used for checkpoint selection), not `data/val`. Power cannot be measured from Python: measure it on the phone and pass `--avg-power-mw`; an unmeasured row is written as `NOT_MEASURED`.

The evaluator writes `results/predictions.json`, `results/predictions.jsonl`, and `results/results.csv`. Cached `.npy` landmark sequences in `data/val/<WORD>/` are preferred; `.mp4` clips are processed through `predict()` when no cache exists.

For a bundle from the repository root (models and vocabulary must be included, otherwise `predict()` cannot run):

```bash
zip -r team_name.zip README.md Dockerfile vocab.json src results artifacts/model_int8.onnx artifacts/model_seed2_int8.onnx artifacts/model_seed3_int8.onnx quantize_and_eval.py train.py build_dataset.py requirements-train.txt
```

## Docker (offline inference)

```bash
docker build -t echogesture .
docker run --rm --network none -v "$PWD/clips:/clips" echogesture /clips/test_0412.mp4
```
