#!/usr/bin/env python3
"""End-to-end latency (decode + MediaPipe + ONNX) over real clips; model-only latency hides MediaPipe."""
import argparse
import time
from pathlib import Path

import numpy as np

from src.main import predict

parser = argparse.ArgumentParser()
parser.add_argument("clips", type=Path, help="folder of .mp4 clips (searched recursively)")
parser.add_argument("--limit", type=int, default=30)
args = parser.parse_args()
paths = sorted(args.clips.rglob("*.mp4"))[: args.limit]
predict(str(paths[0]))  # warm-up: loads sessions / MediaPipe assets
times = []
for path in paths:
    start = time.perf_counter()
    predict(str(path))
    times.append((time.perf_counter() - start) * 1000.0)
print(f"{len(times)} clips | end-to-end per 64-frame clip: median {np.median(times):.0f} ms, "
      f"p95 {np.percentile(times, 95):.0f} ms, mean per sampled frame {np.mean(times) / 64:.1f} ms")
