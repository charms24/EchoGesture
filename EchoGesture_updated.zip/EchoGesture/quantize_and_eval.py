#!/usr/bin/env python3
"""Quantize up to three ONNX seeds and evaluate data/val submission metrics."""
from __future__ import annotations

import argparse
import csv
import json
import os
import platform
import time
from pathlib import Path

import numpy as np
import onnxruntime as ort
from onnxruntime.quantization import (CalibrationDataReader, QuantFormat, QuantType,
                                      quantize_static)

from src.preprocess import NUM_LANDMARKS, engineer_model_features, extract_keypoints


class KeypointCalibration(CalibrationDataReader):
    """Feeds real engineered (1, 64, 486) clips so activation ranges are realistic."""

    def __init__(self, input_name: str, files: list[Path]):
        self._batches = iter(
            {input_name: engineer_model_features(np.load(f, allow_pickle=False))[np.newaxis]}
            for f in files)

    def get_next(self):
        return next(self._batches, None)


def calibration_files(folder: Path, vocab: dict[str, int], limit: int, seed: int) -> list[Path]:
    """Class-balanced sample of cached (64,162) clips, original (non-_aug) clips first."""
    rng = np.random.default_rng(seed)
    per_class = max(1, limit // max(1, len(vocab)))
    files: list[Path] = []
    for word in vocab:
        clips = sorted(p for p in (folder / word).glob("*.npy") if not p.stem.endswith("_aug"))
        rng.shuffle(clips)
        files.extend(clips[:per_class])
    return files


def quantize_int8(source: Path, target: Path, calibration: list[Path]) -> None:
    """Static INT8: weights AND activations of every Conv/MatMul/Gemm are quantized."""
    if not calibration:
        raise SystemExit("Static INT8 needs real calibration clips: put cached .npy files "
                         "in data/train/<WORD>/ (or pass --calib).")
    input_name = ort.InferenceSession(str(source), providers=["CPUExecutionProvider"]
                                      ).get_inputs()[0].name
    quantize_static(
        str(source), str(target), KeypointCalibration(input_name, calibration),
        quant_format=QuantFormat.QOperator,      # explicit QLinearConv / QLinearMatMul nodes
        activation_type=QuantType.QUInt8, weight_type=QuantType.QInt8,
        per_channel=True, op_types_to_quantize=["Conv", "MatMul", "Gemm"],
    )


def vocab_map(path: Path) -> dict[str, int]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(raw, list):
        result = {str(word).upper(): i for i, word in enumerate(raw)}
    elif isinstance(raw, dict):
        result = {str(word).upper(): int(index) for word, index in raw.items()}
    else:
        raise ValueError("vocab must be a list of words or word-to-ID object")
    if not result or sorted(result.values()) != list(range(len(result))):
        raise ValueError("vocabulary IDs must be contiguous from zero")
    return result


def validation_sources(folder: Path, vocab: dict[str, int]) -> list[tuple[str, str, Path]]:
    """Collect class-labeled clips, preferring cached NPY by matching clip ID."""
    collected: dict[tuple[str, str], dict[str, Path]] = {}
    for class_dir in sorted(folder.iterdir()) if folder.is_dir() else []:
        word = class_dir.name.upper()
        if not class_dir.is_dir() or word not in vocab:
            continue
        for path in sorted(class_dir.iterdir()):
            if path.suffix.lower() not in {".mp4", ".npy"} or path.stem.endswith("_aug"):
                continue
            key = (word, path.stem)
            collected.setdefault(key, {})[path.suffix.lower()] = path
    sources = []
    for (word, clip_id), paths in sorted(collected.items()):
        cached = paths.get(".npy")
        video = paths.get(".mp4")
        if cached is not None:
            sources.append((word, clip_id, cached))
        elif video is not None:
            sources.append((word, clip_id, video))
    return sources


def corrupt_keypoints(keypoints: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    points = np.asarray(keypoints, dtype=np.float32).reshape(64, NUM_LANDMARKS, 3).copy()
    points[:, rng.random(NUM_LANDMARKS) < 0.10, :] = 0.0
    observed = np.any(points != 0.0, axis=2)
    noise = rng.normal(0.0, 0.01, size=points.shape).astype(np.float32)
    points += noise * observed[:, :, None]
    return points.reshape(64, NUM_LANDMARKS * 3)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=Path("artifacts/model.onnx"))
    parser.add_argument("--quantized", type=Path, default=Path("artifacts/model_int8.onnx"))
    parser.add_argument("--model-seed2", type=Path, default=Path("artifacts/model_seed2.onnx"))
    parser.add_argument("--quantized-seed2", type=Path, default=Path("artifacts/model_seed2_int8.onnx"))
    parser.add_argument("--model-seed3", type=Path, default=Path("artifacts/model_seed3.onnx"))
    parser.add_argument("--quantized-seed3", type=Path, default=Path("artifacts/model_seed3_int8.onnx"))
    parser.add_argument("--vocab", type=Path, default=Path("data/vocab.json"))
    parser.add_argument("--val", type=Path, default=Path("data/val"))
    parser.add_argument("--results", type=Path, default=Path("results"))
    parser.add_argument("--calib", type=Path, default=Path("data/train"),
                        help="folder of cached (64,162) .npy clips used to calibrate INT8 activations")
    parser.add_argument("--calib-clips", type=int, default=200)
    parser.add_argument("--max-models", type=int, default=0,
                        help="ship only the first N seeds (0 = all that exist); size/latency budgets "
                             "are summed over shipped models")
    parser.add_argument("--thermal-minutes", type=float, default=0.0,
                        help="run a sustained inference loop of this many minutes (10 for the "
                             "official metric) and report latency drift; 0 = skip")
    parser.add_argument("--avg-power-mw", type=float, default=None,
                        help="average power in mW measured on the phone (e.g. Perfetto / "
                             "batterystats); this script cannot measure power itself")
    parser.add_argument("--device", default=None,
                        help='device label for results.csv, e.g. "Galaxy S25, Snapdragon 8 Elite"')
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()

    vocab = vocab_map(args.vocab)
    calibration = calibration_files(args.calib, vocab, args.calib_clips, args.seed)
    print(f"Calibrating INT8 activations on {len(calibration)} clips from {args.calib}")
    args.quantized.parent.mkdir(parents=True, exist_ok=True)
    quantize_int8(args.model, args.quantized, calibration)
    model_paths = [args.quantized]
    for source, target in ((args.model_seed2, args.quantized_seed2),
                           (args.model_seed3, args.quantized_seed3)):
        if source.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            quantize_int8(source, target, calibration)
        if target.is_file():
            model_paths.append(target)
    if args.max_models:
        model_paths = model_paths[:args.max_models]
        for stale in (args.quantized_seed2, args.quantized_seed3):
            if stale not in model_paths and stale.is_file():
                stale.unlink()  # inference loads every *_int8.onnx that exists

    combined_size_mb = sum(path.stat().st_size for path in model_paths) / 1_000_000
    if combined_size_mb >= 20:
        raise SystemExit(f"Combined INT8 model size is {combined_size_mb:.4f} MB; must be < 20 MB")

    sources = validation_sources(args.val, vocab)
    if not sources:
        raise SystemExit(f"No class-labeled .npy or .mp4 clips found under {args.val}/<WORD>/")

    import src.main as inference
    inference.MODEL_PATH = args.quantized.resolve()
    inference.SEED2_MODEL_PATH = args.quantized_seed2.resolve()
    inference.SEED3_MODEL_PATH = args.quantized_seed3.resolve()
    inference.VOCAB_PATH = args.vocab.resolve()
    inference._sessions = None
    inference._vocab = None

    rng = np.random.default_rng(args.seed)
    predictions: list[dict] = []
    latencies: list[float] = []
    clean_correct = robust_correct = 0
    for index, (truth, clip_id, source) in enumerate(sources, start=1):
        raw_keypoints: np.ndarray | None = None
        if source.suffix.lower() == ".npy":
            cached = np.asarray(np.load(source, allow_pickle=False), dtype=np.float32)
            if cached.shape == (64, 162):
                raw_keypoints = cached
                result = inference.predict_keypoints(raw_keypoints, clip_id)
            elif cached.shape == (64, 486):
                result = inference.predict_engineered(cached, clip_id)
                raw_keypoints = cached[:, :162]
            else:
                raise ValueError(f"{source}: expected (64,162) or (64,486), got {cached.shape}")
        else:
            # Keep the public video inference path when no cached landmark file exists.
            result = inference.predict(str(source))
            raw_keypoints = extract_keypoints(source)

        predictions.append(result)
        latencies.append(float(result["latency_ms"]))
        clean_correct += result["prediction"] == truth

        noisy = corrupt_keypoints(raw_keypoints, rng)
        noisy_result = inference.predict_keypoints(noisy, clip_id)
        robust_correct += noisy_result["prediction"] == truth
        if index % 25 == 0 or index == len(sources):
            print(f"Evaluated {index}/{len(sources)} validation clips", flush=True)

    clean_top1 = clean_correct / len(sources) * 100.0
    robust_top1 = robust_correct / len(sources) * 100.0
    robustness_drop = clean_top1 - robust_top1
    p95_latency = float(np.percentile(latencies, 95))
    runtime = f"ONNX Runtime {ort.__version__} INT8 CPUExecutionProvider"
    device = args.device or f"{platform.machine() or 'unknown'} (cpu_count={os.cpu_count()})"

    # Sustained-load drift: median latency of the last minute vs the first minute.
    thermal_drift = None
    if args.thermal_minutes > 0:
        clip = np.asarray(np.load(sources[0][2], allow_pickle=False), dtype=np.float32)
        if clip.shape != (64, 162):
            clip = clip[:, :162]
        stamps: list[tuple[float, float]] = []
        begin = time.perf_counter()
        while time.perf_counter() - begin < args.thermal_minutes * 60.0:
            stamps.append((time.perf_counter() - begin,
                           float(inference.predict_keypoints(clip, "thermal")["latency_ms"])))
        window = min(60.0, args.thermal_minutes * 30.0)
        first = [ms for t, ms in stamps if t <= window]
        last = [ms for t, ms in stamps if t >= args.thermal_minutes * 60.0 - window]
        thermal_drift = (float(np.median(last)) / float(np.median(first)) - 1.0) * 100.0

    def row(metric, target, measured, unit, passed):
        return {"metric": metric, "target": target,
                "measured": "NOT_MEASURED" if measured is None else f"{measured:.4f}",
                "unit": unit, "device": device, "runtime": runtime,
                "pass": "NOT_MEASURED" if measured is None else ("PASS" if passed else "FAIL")}

    rows = [
        row("top1_accuracy", ">=70", clean_top1, "%", clean_top1 >= 70.0),
        row("latency_p95", "<=50", p95_latency, "ms", p95_latency <= 50.0),
        row("model_size", "<=20", combined_size_mb, "MB", combined_size_mb <= 20.0),
        row("accuracy_drop_robustness", "<=5", robustness_drop, "pt", robustness_drop <= 5.0),
        row("avg_power", "<=500", args.avg_power_mw, "mW",
            args.avg_power_mw is not None and args.avg_power_mw <= 500.0),
        row("thermal_drift_10min", "<=20", thermal_drift, "%",
            thermal_drift is not None and thermal_drift <= 20.0),
    ]

    args.results.mkdir(parents=True, exist_ok=True)
    with (args.results / "predictions.jsonl").open("w", encoding="utf-8") as handle:
        for prediction in predictions:
            handle.write(json.dumps(prediction, separators=(",", ":")) + "\n")
    (args.results / "predictions.json").write_text(
        json.dumps(predictions, indent=2) + "\n", encoding="utf-8")
    with (args.results / "results.csv").open("w", newline="", encoding="utf-8") as handle:
        columns = ["metric", "target", "measured", "unit", "device", "runtime", "pass"]
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Top-1={clean_top1:.2f}% | robust Top-1={robust_top1:.2f}% | "
          f"drop={robustness_drop:.2f} pt | combined size={combined_size_mb:.4f} MB | "
          f"combined P95={p95_latency:.2f} ms")
    print(f"Wrote {args.results / 'predictions.jsonl'}, {args.results / 'predictions.json'}, "
          f"and {args.results / 'results.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
